## To run the program

Create .apxc file

Go to File -> New -> Apex Class
To create .vfp

Go to File -> New -> Visualforce Page

## To Preview

1. Save the code and copy the URL
2. Paste it on a new tab
3. Modify the URL by replacing part after _ui with apex/Calculator (name of the .vfp file)
