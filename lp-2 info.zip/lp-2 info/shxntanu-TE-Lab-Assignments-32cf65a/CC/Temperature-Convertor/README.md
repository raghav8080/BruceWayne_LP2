## To execute anonymous window

```apxc
TempConvert t = new TempConvert();
t.convert(5);
```
