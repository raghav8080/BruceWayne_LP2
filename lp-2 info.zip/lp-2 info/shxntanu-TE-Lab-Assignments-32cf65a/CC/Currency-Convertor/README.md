# To execute anonymous window

```java
CurrencyConverter c = new CurrencyConverter();
c.convertCurrency('INR','USD',80);
```
