# To execute anonymous window

```java
ElectricityBill e = new ElectricityBill();
e.calculate_amt(350);
```
