# Laboratory Practice 2

List of PS for Practical:

1. [Graph (BFS/DFS)](01-Graph/graph.cpp)
2. [A Star Algorithm](02-A-Star/a_star.py)
3. [MST](03-Greedy/mst.py)
4. Prim's MST (same as above) [Python](03-Greedy/mst.py) [CPP](03-Greedy/prims.cpp)
5. [Kruskal's MST](03-Greedy/kruskal-mst.py)
6. [CSP (N Queens)](04-CSP/n-queens.cpp)
7. [Chatbot](05-Chatbot/chatbot.py)
8. [Expert System](06-Expert-System/expert-system.py)
