### Problem Statement 13

Design and develop Student Database custom Application using Sales Force Cloud:
Make student details as inputs from user viz; first name, last name, DOB,
Contact number, e—mail id, gender, Adhaar or PAN number, et cetra;
Further formulate the Age from DOB (date of birth) & then display the
eligblity status for voting in the election

![Screenshot 2024-05-09 083746](https://github.com/Ayush-Bulbule/PICT-Lab/assets/69710917/b7af3591-2ab0-400e-867c-73e0929ce1cd)
![Screenshot 2024-05-09 083825](https://github.com/Ayush-Bulbule/PICT-Lab/assets/69710917/838b8d4e-0d24-4af8-8939-76aaebf3d90e)
![Screenshot 2024-05-09 083901](https://github.com/Ayush-Bulbule/PICT-Lab/assets/69710917/7f08f267-d1f0-41f0-b97e-e65d64ac43f9)
![Screenshot 2024-05-09 084005](https://github.com/Ayush-Bulbule/PICT-Lab/assets/69710917/bd6b2158-7c0c-47c3-8d2b-d5289f2c9226)

![Screenshot 2024-05-09 084311](https://github.com/Ayush-Bulbule/PICT-Lab/assets/69710917/5aaebac3-f119-4e7b-bfb5-9ee70e889338)

### Problem Statement 14

CC: Design and develop Employee Database custom Application using
Sales Force Cloud:
